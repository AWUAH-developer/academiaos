import React, { useEffect, useState } from 'react';
import {
  AccessibilityInfo,
  Image,
  StyleSheet,
  View,
  type LayoutChangeEvent,
} from 'react-native';
import { Text } from 'react-native';
import { colors } from '@/theme';

const WORD = 'AcademiaOS';
const HOLD_MS = 4300;
const EAT_STEP_MS = 115;
const EMPTY_PAUSE_MS = 220;
const WRITE_STEP_MS = 75;

type Mode = 'hold' | 'eat' | 'write';

export function DevourLogo({ size = 32 }: { size?: number }) {
  const [mode, setMode] = useState<Mode>('hold');
  const [step, setStep] = useState(0);
  const [wordWidth, setWordWidth] = useState(0);
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    AccessibilityInfo.isReduceMotionEnabled()
      .then(setReducedMotion)
      .catch(() => setReducedMotion(false));
  }, []);

  useEffect(() => {
    if (reducedMotion) {
      setMode('hold');
      setStep(0);
      return;
    }

    let timer: ReturnType<typeof setTimeout>;

    if (mode === 'hold') {
      timer = setTimeout(() => {
        setStep(0);
        setMode('eat');
      }, HOLD_MS);
    } else if (mode === 'eat') {
      if (step < WORD.length) {
        timer = setTimeout(() => setStep((value) => value + 1), EAT_STEP_MS);
      } else {
        timer = setTimeout(() => {
          setStep(0);
          setMode('write');
        }, EMPTY_PAUSE_MS);
      }
    } else if (step < WORD.length) {
      timer = setTimeout(() => setStep((value) => value + 1), WRITE_STEP_MS);
    } else {
      timer = setTimeout(() => {
        setStep(0);
        setMode('hold');
      }, 180);
    }

    return () => clearTimeout(timer);
  }, [mode, reducedMotion, step]);

  const onWordLayout = (event: LayoutChangeEvent) => {
    const width = event.nativeEvent.layout.width;
    if (width > 0 && Math.abs(width - wordWidth) > 1) setWordWidth(width);
  };

  const pacmanSize = size * 0.78;
  const progress = mode === 'eat' ? Math.min(step / WORD.length, 1) : 0;
  const pacmanLeft = Math.max(0, wordWidth * progress - pacmanSize * 0.25);

  return (
    <View accessibilityRole="image" accessibilityLabel="AcademiaOS" style={styles.outer}>
      <Image
        source={require('../../assets/icon.png')}
        style={{ width: size * 1.24, height: size * 1.24, borderRadius: size * 0.28 }}
        resizeMode="cover"
      />

      <View style={[styles.wordArea, { minHeight: size * 1.18 }]}>
        <View onLayout={onWordLayout} style={styles.word}>
          {WORD.split('').map((letter, index) => {
            const visible =
              reducedMotion ||
              mode === 'hold' ||
              (mode === 'eat' ? index >= step : index < step);

            return (
              <Text
                key={`${letter}-${index}`}
                style={[
                  styles.letter,
                  {
                    fontSize: size,
                    lineHeight: size * 1.05,
                    opacity: visible ? 1 : 0,
                  },
                ]}
              >
                {letter}
              </Text>
            );
          })}
        </View>

        {!reducedMotion && mode === 'eat' && (
          <View
            pointerEvents="none"
            style={[
              styles.pacman,
              {
                left: pacmanLeft,
                width: pacmanSize,
                height: pacmanSize,
                borderRadius: pacmanSize / 2,
                top: (size * 1.18 - pacmanSize) / 2,
              },
            ]}
          >
            <View
              style={[
                styles.mouth,
                {
                  right: -1,
                  top: pacmanSize * 0.31,
                  borderTopWidth: pacmanSize * 0.17,
                  borderBottomWidth: pacmanSize * 0.17,
                  borderRightWidth: pacmanSize * 0.34,
                },
              ]}
            />
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  outer: {
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  wordArea: {
    position: 'relative',
    justifyContent: 'center',
  },
  word: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  letter: {
    color: colors.navy,
    fontWeight: '900',
    letterSpacing: -1.15,
  },
  pacman: {
    position: 'absolute',
    zIndex: 3,
    backgroundColor: colors.gold,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 4,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  mouth: {
    position: 'absolute',
    width: 0,
    height: 0,
    borderTopColor: 'transparent',
    borderBottomColor: 'transparent',
    borderRightColor: colors.background,
  },
});
