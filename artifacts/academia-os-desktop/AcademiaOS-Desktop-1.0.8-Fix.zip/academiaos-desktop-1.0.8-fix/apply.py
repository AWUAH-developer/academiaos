#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

PROJECT_CANDIDATES = [
    Path('/home/runner/workspace/artifacts/academia-os-desktop'),
    Path.cwd() / 'artifacts' / 'academia-os-desktop',
    Path.cwd(),
]


def locate_project() -> Path:
    for candidate in PROJECT_CANDIDATES:
        if (candidate / 'package.json').is_file() and (candidate / 'src').is_dir():
            return candidate.resolve()
    raise SystemExit('AcademiaOS desktop project was not found.')


def run(command: list[str], cwd: Path) -> None:
    print(f"\n$ {' '.join(command)}")
    subprocess.run(command, cwd=cwd, check=True)


TITLE_BAR = r'''import React from 'react';

/**
 * Augment React.CSSProperties to include the Electron-specific
 * -webkit-app-region CSS property used for native window dragging.
 * This extension is file-scoped: it only affects this module.
 */
declare module 'react' {
  interface CSSProperties {
    WebkitAppRegion?: 'drag' | 'no-drag';
  }
}

interface Props {
  schoolName?: string;
  schoolLogoUrl?: string | null;
  userName?: string;
  onLogout(): void;
}

function schoolInitials(name: string) {
  const ignored = new Set(['and', 'of', 'the', '&']);
  const words = String(name || '')
    .trim()
    .split(/\s+/)
    .map((word) => word.replace(/[^A-Za-z0-9]/g, ''))
    .filter(Boolean);
  const meaningful = words.filter(
    (word) => !ignored.has(word.toLowerCase()),
  );
  const source = meaningful.length ? meaningful : words;

  if (!source.length) return 'SCH';
  if (source.length === 1) {
    return source[0].slice(0, 3).toUpperCase();
  }

  return source
    .slice(0, 3)
    .map((word) => word[0])
    .join('')
    .toUpperCase();
}

function resolveSchoolLogoUrl(value?: string | null) {
  const logo = String(value ?? '').trim();

  if (!logo || ['null', 'undefined', 'none'].includes(logo.toLowerCase())) {
    return null;
  }

  if (/^(data:|blob:|file:|https?:\/\/)/i.test(logo)) {
    return logo;
  }

  if (logo.startsWith('//')) {
    return `https:${logo}`;
  }

  try {
    return new URL(logo, 'https://academiaos.cc').toString();
  } catch {
    return null;
  }
}

export default function TitleBar({
  schoolName,
  schoolLogoUrl,
  userName,
  onLogout,
}: Props) {
  const resolvedLogoUrl = React.useMemo(
    () => resolveSchoolLogoUrl(schoolLogoUrl),
    [schoolLogoUrl],
  );
  const [logoFailed, setLogoFailed] = React.useState(false);

  React.useEffect(() => {
    setLogoFailed(false);
  }, [resolvedLogoUrl, schoolName]);

  const showLogo = Boolean(resolvedLogoUrl && !logoFailed);

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        height: 'var(--titlebar-h)',
        background: 'var(--chalk-dark)',
        color: '#fff',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        zIndex: 100,
        WebkitAppRegion: 'drag',
        userSelect: 'none',
        padding: '0 16px 0 80px',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span
          style={{
            fontSize: 13,
            fontWeight: 800,
            letterSpacing: '.04em',
          }}
          aria-label="AcademiaOS"
        >
          <span style={{ color: '#fff8ea' }}>Academia</span>
          <span style={{ color: '#f4c542' }}>OS</span>
        </span>

        {schoolName && (
          <>
            <span style={{ opacity: 0.35 }}>·</span>

            {showLogo ? (
              <img
                key={resolvedLogoUrl ?? undefined}
                src={resolvedLogoUrl ?? undefined}
                alt={`${schoolName} logo`}
                onError={() => setLogoFailed(true)}
                style={{
                  width: 28,
                  height: 28,
                  borderRadius: 7,
                  objectFit: 'contain',
                  background: '#fff',
                  padding: 2,
                }}
              />
            ) : (
              <span
                title={`${schoolName} initials logo`}
                aria-label={`${schoolName} initials logo`}
                style={{
                  width: 28,
                  height: 28,
                  borderRadius: 7,
                  display: 'grid',
                  placeItems: 'center',
                  background: '#1F5C46',
                  color: '#F4C542',
                  fontSize: 9,
                  fontWeight: 900,
                  letterSpacing: '.04em',
                }}
              >
                {schoolInitials(schoolName)}
              </span>
            )}

            <span style={{ fontSize: 12, opacity: 0.75 }}>
              {schoolName}
            </span>
          </>
        )}
      </div>

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          WebkitAppRegion: 'no-drag',
        }}
      >
        {userName && (
          <span style={{ fontSize: 12, opacity: 0.65 }}>
            {userName}
          </span>
        )}

        <button
          onClick={onLogout}
          style={{
            background: 'rgba(255,255,255,.12)',
            border: 'none',
            color: '#fff',
            padding: '3px 10px',
            borderRadius: 4,
            fontSize: 11,
            cursor: 'pointer',
            fontWeight: 600,
          }}
        >
          Sign out
        </button>
      </div>
    </div>
  );
}
'''

LOGIN_SCREEN = r'''import React, { useState } from 'react';
import DevourLogo from '../components/DevourLogo';
import { useAuth } from '../store/auth';

export default function LoginScreen() {
  const { login } = useAuth();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(event: React.FormEvent) {
    event.preventDefault();

    if (!username.trim() || !password) return;

    setLoading(true);
    setError('');

    const result = await login(
      username.trim().toLowerCase(),
      password,
    );

    setLoading(false);

    if (!result.ok) {
      setError(
        result.error ??
          'Sign-in failed. Check your username and password.',
      );
    }
  }

  return (
    <main className="desktop-auth-page">
      <div className="desktop-auth-shell">
        <section className="desktop-auth-brand">
          <div className="desktop-auth-brand-icon">
            <img
              src="./brand-logo.jpg"
              alt="AcademiaOS"
            />
          </div>

          <div className="desktop-auth-brand-copy">
            <DevourLogo />

            <p>School Command Centre</p>
          </div>
        </section>

        <section className="desktop-auth-introduction">
          <h1>Sign in with username and password</h1>

          <p className="desktop-auth-description">
            Use the username and password assigned by your school
            administrator.
          </p>
        </section>

        {error && (
          <div className="desktop-auth-error" role="alert">
            {error}
          </div>
        )}

        <form
          className="desktop-auth-form"
          onSubmit={handleSubmit}
        >
          <div className="desktop-auth-field">
            <label htmlFor="desktop-username">
              Username
            </label>

            <input
              id="desktop-username"
              type="text"
              value={username}
              onChange={(event) =>
                setUsername(event.target.value)
              }
              placeholder="Enter your username"
              autoComplete="username"
              autoFocus
              required
            />
          </div>

          <div className="desktop-auth-field">
            <label htmlFor="desktop-password">
              Password
            </label>

            <div className="desktop-auth-password-control">
              <input
                id="desktop-password"
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(event) =>
                  setPassword(event.target.value)
                }
                placeholder="Enter your password"
                autoComplete="current-password"
                required
              />

              <button
                type="button"
                className="desktop-auth-password-toggle"
                onClick={() => setShowPassword((visible) => !visible)}
                onMouseDown={(event) => event.preventDefault()}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
                aria-pressed={showPassword}
              >
                {showPassword ? 'Hide' : 'Show'}
              </button>
            </div>
          </div>

          <button
            className="desktop-auth-submit"
            type="submit"
            disabled={loading}
          >
            {loading
              ? 'Signing in…'
              : 'Sign in to AcademiaOS'}
          </button>
        </form>

        <footer className="desktop-auth-footer">
          AcademiaOS™ © 2026. All rights reserved.
        </footer>
      </div>
    </main>
  );
}
'''

PASSWORD_CSS = r'''

/* Password visibility control */
.desktop-auth-password-control {
  position: relative;
}

.desktop-auth-password-control input {
  padding-right: 86px;
}

.desktop-auth-password-toggle {
  position: absolute;
  top: 50%;
  right: 11px;
  min-width: 62px;
  padding: 7px 10px;
  border: 0;
  border-radius: 10px;
  background: #edf7f2;
  color: #1f5c46;
  font-family: inherit;
  font-size: 13px;
  font-weight: 900;
  line-height: 1;
  cursor: pointer;
  transform: translateY(-50%);
}

.desktop-auth-password-toggle:hover {
  background: #dff1e8;
}

.desktop-auth-password-toggle:focus-visible {
  outline: 3px solid rgba(31, 92, 70, 0.24);
  outline-offset: 2px;
}
'''


def main() -> None:
    project = locate_project()
    print(f'Applying desktop fix in: {project}')

    title_path = project / 'src' / 'components' / 'TitleBar.tsx'
    login_path = project / 'src' / 'screens' / 'LoginScreen.tsx'
    css_path = project / 'src' / 'index.css'
    package_path = project / 'package.json'

    required = [title_path, login_path, css_path, package_path]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise SystemExit('Missing required files:\n' + '\n'.join(missing))

    title_path.write_text(TITLE_BAR, encoding='utf-8')
    login_path.write_text(LOGIN_SCREEN, encoding='utf-8')

    css = css_path.read_text(encoding='utf-8')
    marker = '/* Password visibility control */'
    if marker not in css:
        css = css.rstrip() + PASSWORD_CSS + '\n'
        css_path.write_text(css, encoding='utf-8')

    package = json.loads(package_path.read_text(encoding='utf-8'))
    package['version'] = '1.0.8'
    package_path.write_text(
        json.dumps(package, indent=2, ensure_ascii=False) + '\n',
        encoding='utf-8',
    )

    run(['pnpm', 'typecheck'], project)
    run(['pnpm', 'build'], project)

    workspace = project.parents[1]
    relative_files = [
        str(title_path.relative_to(workspace)),
        str(login_path.relative_to(workspace)),
        str(css_path.relative_to(workspace)),
        str(package_path.relative_to(workspace)),
    ]

    run(['git', 'add', *relative_files], workspace)

    status = subprocess.run(
        ['git', 'diff', '--cached', '--quiet'],
        cwd=workspace,
    ).returncode

    if status != 0:
        run(
            [
                'git',
                'commit',
                '-m',
                'Fix desktop logo fallback and password visibility',
            ],
            workspace,
        )
    else:
        print('\nNo new Git changes were required.')

    run(['git', 'push', 'origin', 'main'], workspace)

    print('\nDESKTOP 1.0.8 FIX APPLIED AND PUSHED')
    print('The Windows installer workflow can now build version 1.0.8.')


if __name__ == '__main__':
    try:
        main()
    except subprocess.CalledProcessError as error:
        print(
            f'\nFAILED: {error.cmd} returned status {error.returncode}',
            file=sys.stderr,
        )
        raise SystemExit(error.returncode)
