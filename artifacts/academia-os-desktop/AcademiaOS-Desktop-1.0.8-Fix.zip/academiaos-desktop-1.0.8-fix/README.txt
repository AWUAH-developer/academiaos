AcademiaOS Desktop 1.0.8 Fix

This patch:
- prevents a broken school logo image from appearing
- resolves relative logo URLs against https://academiaos.cc
- falls back to school initials when the logo cannot load
- adds Show/Hide password control to desktop login
- updates desktop version to 1.0.8
- runs typecheck and build
- commits and pushes the fix to main

Replit Shell command after uploading this ZIP to /home/runner/workspace:

rm -rf /tmp/academia108 && mkdir -p /tmp/academia108 && unzip -o /home/runner/workspace/AcademiaOS-Desktop-1.0.8-Fix.zip -d /tmp/academia108 && python3 /tmp/academia108/apply.py
