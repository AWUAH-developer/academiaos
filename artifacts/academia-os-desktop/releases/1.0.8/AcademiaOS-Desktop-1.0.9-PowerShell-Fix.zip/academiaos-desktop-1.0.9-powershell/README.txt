AcademiaOS Desktop 1.0.9 PowerShell repair

Fixes:
1. Loads the real school logo through the authenticated Electron main process.
2. Syncs classes into the encrypted local cache and displays class names instead of UUIDs.
3. Restores barcode attendance. A USB scanner or admission number marks the learner PRESENT.

Run from Replit after uploading this ZIP:
pwsh -NoProfile -ExecutionPolicy Bypass -File ./Fix-AcademiaOS-Desktop-1.0.9.ps1
