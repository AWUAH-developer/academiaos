param(
  [string]$Workspace = "/home/runner/workspace",
  [string]$Repository = "AWUAH-developer/academiaos"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

function Step([string]$Text) {
  Write-Host ""
  Write-Host "===== $Text =====" -ForegroundColor Cyan
}

$Project = Join-Path $Workspace "artifacts/academia-os-desktop"
$Helper = Join-Path $PSScriptRoot "apply_fix.py"

if (-not (Test-Path $Project)) {
  throw "Desktop project not found: $Project"
}

if (-not (Test-Path $Helper)) {
  throw "Repair helper not found: $Helper"
}

Step "APPLYING VERSION 1.0.9 REPAIR"
& python3 $Helper $Workspace
if ($LASTEXITCODE -ne 0) {
  throw "Source repair failed."
}

Step "TYPECHECK"
Push-Location $Project
try {
  & pnpm typecheck
  if ($LASTEXITCODE -ne 0) { throw "Typecheck failed." }

  Step "PRODUCTION BUILD"
  & pnpm build
  if ($LASTEXITCODE -ne 0) { throw "Build failed." }
}
finally {
  Pop-Location
}

Step "COMMIT AND PUSH"
Push-Location $Workspace
try {
  $Paths = @(
    "artifacts/academia-os-desktop/package.json",
    "artifacts/academia-os-desktop/src/App.tsx",
    "artifacts/academia-os-desktop/src/api/client.ts",
    "artifacts/academia-os-desktop/src/components/TitleBar.tsx",
    "artifacts/academia-os-desktop/src/screens/LearnersScreen.tsx",
    "artifacts/academia-os-desktop/src/screens/AttendanceScreen.tsx",
    "artifacts/academia-os-desktop/src/store/sync.ts",
    "artifacts/academia-os-desktop/electron/sqlite.ts",
    "artifacts/academia-os-desktop/electron/ipc-handlers.ts"
  )

  & git add -- $Paths
  if ($LASTEXITCODE -ne 0) { throw "git add failed." }

  $Changed = git status --porcelain -- $Paths
  if ($Changed) {
    & git commit -m "Restore desktop logo classes and barcode attendance"
    if ($LASTEXITCODE -ne 0) { throw "git commit failed." }
  }
  else {
    Write-Host "No new changes needed."
  }

  & git push origin main
  if ($LASTEXITCODE -ne 0) { throw "git push failed." }

  $Head = (git rev-parse HEAD).Trim()
}
finally {
  Pop-Location
}

Step "START GITHUB WINDOWS BUILD"
$Workflows = gh workflow list `
  --repo $Repository `
  --all `
  --json id,name,path,state |
  ConvertFrom-Json

$Workflow = $Workflows |
  Where-Object {
    $_.state -eq "active" -and
    (($_.name + " " + $_.path) -match "(?i)desktop|windows|installer|electron")
  } |
  Select-Object -First 1

if (-not $Workflow) {
  throw "No active desktop Windows workflow was found."
}

& gh workflow run $Workflow.id --repo $Repository --ref main
if ($LASTEXITCODE -ne 0) {
  throw "Could not start GitHub workflow."
}

Write-Host ""
Write-Host "DESKTOP 1.0.9 SOURCE FIXED AND PUSHED" -ForegroundColor Green
Write-Host "Commit: $Head"
Write-Host "GitHub workflow: $($Workflow.name)"
Write-Host ""
Write-Host "The new installer fixes:"
Write-Host "  1. Real school logo loading"
Write-Host "  2. Learner class names instead of UUIDs"
Write-Host "  3. Barcode attendance scanning"
