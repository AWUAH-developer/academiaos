from __future__ import annotations

import re
import shutil
import sys
from datetime import datetime
from pathlib import Path


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8", newline="\n")


def replace_once(text: str, old: str, new: str, label: str) -> str:
    if new in text:
        return text
    if old not in text:
        raise RuntimeError(f"Patch marker not found: {label}")
    return text.replace(old, new, 1)


workspace = Path(sys.argv[1] if len(sys.argv) > 1 else "/home/runner/workspace")
project = workspace / "artifacts/academia-os-desktop"

if not project.exists():
    raise SystemExit(f"Desktop project not found: {project}")

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = Path("/tmp") / f"academiaos-desktop-1.0.9-{stamp}"

files = [
    "package.json",
    "src/App.tsx",
    "src/api/client.ts",
    "src/components/TitleBar.tsx",
    "src/screens/LearnersScreen.tsx",
    "src/screens/AttendanceScreen.tsx",
    "src/store/sync.ts",
    "electron/sqlite.ts",
    "electron/ipc-handlers.ts",
]

for relative in files:
    source = project / relative
    if not source.exists():
        raise RuntimeError(f"Required file missing: {source}")
    destination = backup / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)

print(f"Backup created: {backup}")

# Version
package_path = project / "package.json"
package = read(package_path)
package = re.sub(
    r'"version"\s*:\s*"[^"]+"',
    '"version": "1.0.9"',
    package,
    count=1,
)
write(package_path, package)

# Renderer API
client_path = project / "src/api/client.ts"
client = read(client_path)

if "export const media =" not in client:
    marker = "// ── Local DB"
    media = """// ── Protected media ────────────────────────────────────────────────────────────
export const media = {
  loadImage: (url: string) =>
    invoke<ApiResult<{ dataUrl: string }>>('media:loadImage', { url }),
};

"""
    if marker not in client:
        raise RuntimeError("Could not locate Local DB marker in client.ts")
    client = client.replace(marker, media + marker, 1)

client = replace_once(
    client,
    "  first_name: string; last_name: string; class_id: string | null;\n"
    "  status: string; photo_url: string | null; badge_code: string | null;",
    "  first_name: string; last_name: string; class_id: string | null;\n"
    "  class_name: string | null; class_stream: string | null;\n"
    "  status: string; photo_url: string | null; badge_code: string | null;",
    "LocalLearner class fields",
)
write(client_path, client)

# Title bar with authenticated logo loading
titlebar_path = project / "src/components/TitleBar.tsx"
titlebar = r"""import React from 'react';
import { media } from '../api/client';

declare module 'react' {
  interface CSSProperties {
    WebkitAppRegion?: 'drag' | 'no-drag';
  }
}

interface Props {
  schoolName?: string;
  schoolLogoUrl?: string | null;
  userName?: string;
  onLogout(): void;
}

function schoolInitials(name: string) {
  const ignored = new Set(['and', 'of', 'the', '&']);
  const words = String(name || '')
    .trim()
    .split(/\s+/)
    .map((word) => word.replace(/[^A-Za-z0-9]/g, ''))
    .filter(Boolean);
  const meaningful = words.filter(
    (word) => !ignored.has(word.toLowerCase()),
  );
  const source = meaningful.length ? meaningful : words;

  if (!source.length) return 'SCH';
  if (source.length === 1) return source[0].slice(0, 3).toUpperCase();

  return source
    .slice(0, 3)
    .map((word) => word[0])
    .join('')
    .toUpperCase();
}

function resolveLogoUrl(value?: string | null) {
  const logo = String(value ?? '').trim();

  if (!logo || ['null', 'undefined', 'none'].includes(logo.toLowerCase())) {
    return null;
  }

  if (/^(data:|https?:\/\/)/i.test(logo)) return logo;
  if (logo.startsWith('//')) return `https:${logo}`;

  try {
    return new URL(logo, 'https://academiaos.cc').toString();
  } catch {
    return null;
  }
}

export default function TitleBar({
  schoolName,
  schoolLogoUrl,
  userName,
  onLogout,
}: Props) {
  const resolvedLogoUrl = React.useMemo(
    () => resolveLogoUrl(schoolLogoUrl),
    [schoolLogoUrl],
  );
  const [logoSrc, setLogoSrc] = React.useState<string | null>(null);
  const [logoFailed, setLogoFailed] = React.useState(false);

  React.useEffect(() => {
    let active = true;
    setLogoSrc(null);
    setLogoFailed(false);

    if (!resolvedLogoUrl) return () => { active = false; };

    if (resolvedLogoUrl.startsWith('data:image/')) {
      setLogoSrc(resolvedLogoUrl);
      return () => { active = false; };
    }

    media.loadImage(resolvedLogoUrl)
      .then((result) => {
        if (!active) return;
        setLogoSrc(result.ok ? result.dataUrl : resolvedLogoUrl);
      })
      .catch(() => {
        if (active) setLogoSrc(resolvedLogoUrl);
      });

    return () => { active = false; };
  }, [resolvedLogoUrl, schoolName]);

  const showLogo = Boolean(logoSrc && !logoFailed);

  return (
    <div
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        height: 'var(--titlebar-h)',
        background: 'var(--chalk-dark)',
        color: '#fff',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        zIndex: 100,
        WebkitAppRegion: 'drag',
        userSelect: 'none',
        padding: '0 16px 0 80px',
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span
          style={{ fontSize: 13, fontWeight: 800, letterSpacing: '.04em' }}
          aria-label="AcademiaOS"
        >
          <span style={{ color: '#fff8ea' }}>Academia</span>
          <span style={{ color: '#f4c542' }}>OS</span>
        </span>

        {schoolName && (
          <>
            <span style={{ opacity: 0.35 }}>·</span>

            {showLogo ? (
              <img
                src={logoSrc ?? undefined}
                alt={`${schoolName} logo`}
                onError={() => setLogoFailed(true)}
                style={{
                  width: 30,
                  height: 30,
                  borderRadius: 7,
                  objectFit: 'contain',
                  background: '#fff',
                  padding: 2,
                }}
              />
            ) : (
              <span
                title={`${schoolName} logo fallback`}
                style={{
                  width: 30,
                  height: 30,
                  borderRadius: 7,
                  display: 'grid',
                  placeItems: 'center',
                  background: '#1F5C46',
                  color: '#F4C542',
                  fontSize: 9,
                  fontWeight: 900,
                }}
              >
                {schoolInitials(schoolName)}
              </span>
            )}

            <span style={{ fontSize: 12, opacity: 0.75 }}>
              {schoolName}
            </span>
          </>
        )}
      </div>

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          WebkitAppRegion: 'no-drag',
        }}
      >
        {userName && (
          <span style={{ fontSize: 12, opacity: 0.65 }}>{userName}</span>
        )}

        <button
          onClick={onLogout}
          style={{
            background: 'rgba(255,255,255,.12)',
            border: 'none',
            color: '#fff',
            padding: '3px 10px',
            borderRadius: 4,
            fontSize: 11,
            cursor: 'pointer',
            fontWeight: 600,
          }}
        >
          Sign out
        </button>
      </div>
    </div>
  );
}
"""
write(titlebar_path, titlebar)

# Learner class display
learners_path = project / "src/screens/LearnersScreen.tsx"
learners = read(learners_path)
learners = replace_once(
    learners,
    "<td>{l.class_id ?? '—'}</td>",
    "<td>{[l.class_name, l.class_stream].filter(Boolean).join(' ') || 'Unassigned'}</td>",
    "learner class display",
)
write(learners_path, learners)

# Attendance with barcode entry
attendance_path = project / "src/screens/AttendanceScreen.tsx"
attendance = r"""import React, {
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'react';
import {
  db as localDb,
  type AttendanceStatus,
  type LocalLearner,
} from '../api/client';
import { useAuth } from '../store/auth';
import type { useSyncStore } from '../store/sync';

interface Props {
  syncStore: ReturnType<typeof useSyncStore>;
}

const STATUS_OPTS: AttendanceStatus[] = [
  'PRESENT',
  'ABSENT',
  'LATE',
  'EXCUSED',
  'HALF_DAY',
];

const STATUS_COLOR: Record<AttendanceStatus, string> = {
  PRESENT: 'pill-green',
  ABSENT: 'pill-red',
  LATE: 'pill-amber',
  EXCUSED: 'pill-blue',
  HALF_DAY: 'pill-slate',
};

function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

export default function AttendanceScreen({ syncStore }: Props) {
  const { authState } = useAuth();
  const [learners, setLearners] = useState<LocalLearner[]>([]);
  const [attendance, setAttendance] = useState<
    Record<string, AttendanceStatus>
  >({});
  const [saving, setSaving] = useState<Record<string, boolean>>({});
  const [saved, setSaved] = useState<Record<string, boolean>>({});
  const [date, setDate] = useState(todayIso());
  const [loading, setLoading] = useState(true);
  const [scanCode, setScanCode] = useState('');
  const [scanMessage, setScanMessage] = useState('');
  const [scanError, setScanError] = useState(false);
  const scanInput = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const result = await localDb.getLearners();
    if (result.ok) setLearners(result.learners);
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function markAttendance(
    learnerId: string,
    status: AttendanceStatus,
  ) {
    if (authState.status !== 'authenticated') return false;
    const { user } = authState;
    if (!user.school) return false;

    setSaving((value) => ({ ...value, [learnerId]: true }));
    setAttendance((value) => ({ ...value, [learnerId]: status }));

    const result = await localDb.saveAttendance({
      learnerId,
      date,
      status,
      schoolId: user.school.id,
      userId: user.id,
      deviceId: 'desktop',
    });

    setSaving((value) => ({ ...value, [learnerId]: false }));

    if (!result.ok) return false;

    setSaved((value) => ({ ...value, [learnerId]: true }));
    window.setTimeout(() => {
      setSaved((value) => ({ ...value, [learnerId]: false }));
    }, 2000);

    void syncStore.refreshStatus();
    return true;
  }

  async function scanBarcode(event: React.FormEvent) {
    event.preventDefault();
    const code = scanCode.trim().toLowerCase();

    if (!code) {
      scanInput.current?.focus();
      return;
    }

    const learner = learners.find((item) =>
      String(item.badge_code ?? '').trim().toLowerCase() === code ||
      String(item.admission_no ?? '').trim().toLowerCase() === code,
    );

    if (!learner) {
      setScanError(true);
      setScanMessage(`No learner found for barcode: ${scanCode.trim()}`);
      setScanCode('');
      scanInput.current?.focus();
      return;
    }

    const success = await markAttendance(learner.id, 'PRESENT');
    setScanError(!success);
    setScanMessage(
      success
        ? `${learner.first_name} ${learner.last_name} marked PRESENT`
        : `Could not save attendance for ${learner.first_name} ${learner.last_name}`,
    );
    setScanCode('');
    scanInput.current?.focus();
  }

  if (loading) {
    return (
      <div className="empty">
        <span className="spin">⟳</span> Loading…
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 960 }}>
      <div
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: 20,
        }}
      >
        <div>
          <h1>Attendance</h1>
          <p style={{ color: 'var(--text-muted)', fontSize: 13 }}>
            Records save locally and sync when online · {learners.length} learners
          </p>
        </div>

        <input
          className="input"
          type="date"
          value={date}
          onChange={(event) => setDate(event.target.value)}
          style={{ width: 'auto' }}
        />
      </div>

      {!syncStore.status.online && (
        <div
          style={{
            background: '#fef3c7',
            border: '1px solid #fde68a',
            borderRadius: 8,
            padding: '10px 14px',
            marginBottom: 16,
            fontSize: 12,
            fontWeight: 600,
            color: '#92400e',
          }}
        >
          ⚠ Offline. Attendance will sync automatically when connected.
        </div>
      )}

      <div className="card" style={{ marginBottom: 16, padding: 16 }}>
        <div style={{ fontSize: 13, fontWeight: 800, marginBottom: 8 }}>
          Barcode attendance
        </div>

        <form
          onSubmit={scanBarcode}
          style={{ display: 'flex', gap: 10, alignItems: 'center' }}
        >
          <input
            ref={scanInput}
            className="input"
            value={scanCode}
            onChange={(event) => {
              setScanCode(event.target.value);
              setScanMessage('');
            }}
            placeholder="Scan learner barcode or enter admission number…"
            autoComplete="off"
            autoFocus
            style={{ flex: 1 }}
          />

          <button
            type="submit"
            style={{
              minWidth: 130,
              padding: '10px 14px',
              border: 0,
              borderRadius: 8,
              background: 'var(--chalk)',
              color: '#fff',
              fontWeight: 800,
              cursor: 'pointer',
            }}
          >
            Mark Present
          </button>
        </form>

        <div
          style={{
            marginTop: 8,
            minHeight: 18,
            color: scanError ? '#b91c1c' : 'var(--success)',
            fontSize: 12,
            fontWeight: 700,
          }}
        >
          {scanMessage ||
            'USB barcode scanners work automatically. Scan and press Enter.'}
        </div>
      </div>

      {learners.length === 0 ? (
        <div className="empty">
          <p>No learner records. Run a sync first.</p>
        </div>
      ) : (
        <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
          <table className="table">
            <thead>
              <tr>
                <th>Learner</th>
                <th>Admission No.</th>
                <th>Status</th>
                <th>Mark</th>
              </tr>
            </thead>
            <tbody>
              {learners.map((learner) => {
                const current = attendance[learner.id];

                return (
                  <tr key={learner.id}>
                    <td style={{ fontWeight: 600 }}>
                      {learner.first_name} {learner.last_name}
                    </td>
                    <td style={{ fontFamily: 'monospace', fontSize: 12 }}>
                      {learner.admission_no}
                    </td>
                    <td>
                      {current && (
                        <span className={`pill ${STATUS_COLOR[current]}`}>
                          {current}
                        </span>
                      )}
                      {saved[learner.id] && (
                        <span
                          style={{
                            marginLeft: 8,
                            fontSize: 11,
                            color: 'var(--success)',
                          }}
                        >
                          ✓ saved
                        </span>
                      )}
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: 4 }}>
                        {STATUS_OPTS.map((status) => (
                          <button
                            key={status}
                            onClick={() => {
                              void markAttendance(learner.id, status);
                            }}
                            disabled={saving[learner.id]}
                            title={status.replace('_', ' ')}
                            style={{
                              padding: '3px 8px',
                              borderRadius: 4,
                              border: '1px solid var(--border)',
                              fontSize: 10,
                              fontWeight: 700,
                              cursor: 'pointer',
                              background:
                                current === status
                                  ? 'var(--chalk)'
                                  : 'var(--surface)',
                              color:
                                current === status
                                  ? '#fff'
                                  : 'var(--text)',
                              textTransform: 'uppercase',
                            }}
                          >
                            {status.charAt(0)}
                          </button>
                        ))}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
"""
write(attendance_path, attendance)

# Sync reference data immediately after authentication
sync_path = project / "src/store/sync.ts"
sync = read(sync_path)
sync = replace_once(
    sync,
    """      const cursor = statusRes.ok ? statusRes.cursors.find((c) => c.entity_type === 'learners')?.last_synced : null;
      if (cursor) {
        await syncApi.incremental(cursor);
      }
""",
    """      const cursors = statusRes.ok ? statusRes.cursors : [];
      const cursor = cursors.find(
        (c) => c.entity_type === 'learners',
      )?.last_synced;
      const classesReady = cursors.some(
        (c) => c.entity_type === 'classes',
      );

      if (!cursor || !classesReady) {
        await syncApi.initial();
      } else {
        await syncApi.incremental(cursor);
      }
""",
    "sync initial fallback",
)
write(sync_path, sync)

# Trigger sync when authentication becomes available
app_path = project / "src/App.tsx"
app = read(app_path)
if "authState.status === 'authenticated' && navigator.onLine" not in app:
    marker = "  const [screen, setScreen] = React.useState<Screen>('dashboard');\n"
    addition = marker + """
  React.useEffect(() => {
    if (authState.status === 'authenticated' && navigator.onLine) {
      void syncStore.runSync();
    }
  }, [authState.status, syncStore.runSync]);
"""
    app = replace_once(app, marker, addition, "authenticated sync effect")
write(app_path, app)

# Add class cache writer
sqlite_path = project / "electron/sqlite.ts"
sqlite = read(sqlite_path)

if "export function upsertClasses(" not in sqlite:
    class_function = r"""
export function upsertClasses(
  db: InstanceType<typeof Database>,
  rows: Record<string, unknown>[],
): void {
  const statement = db.prepare(`
    INSERT INTO cached_classes
      (id, school_id, name, stream, level, is_active, synced_at)
    VALUES
      (@id, @school_id, @name, @stream, @level, @is_active, datetime('now'))
    ON CONFLICT(id) DO UPDATE SET
      school_id = excluded.school_id,
      name = excluded.name,
      stream = excluded.stream,
      level = excluded.level,
      is_active = excluded.is_active,
      synced_at = datetime('now')
  `);

  const saveRows = db.transaction((items: Record<string, unknown>[]) => {
    for (const row of items) {
      statement.run({
        id: String(row.id ?? ''),
        school_id: String(row.schoolId ?? row.school_id ?? ''),
        name: String(row.name ?? row.className ?? 'Unnamed class'),
        stream: row.stream ?? null,
        level: row.level ?? null,
        is_active:
          (row.isActive ?? row.is_active ?? true) === false ? 0 : 1,
      });
    }
  });

  saveRows(rows);
}

"""
    marker = "export function upsertStaff("
    if marker not in sqlite:
        raise RuntimeError("Could not locate upsertStaff in sqlite.ts")
    sqlite = sqlite.replace(marker, class_function + marker, 1)

write(sqlite_path, sqlite)

# Main process: classes and protected image loading
ipc_path = project / "electron/ipc-handlers.ts"
ipc = read(ipc_path)

ipc = replace_once(
    ipc,
    "import https from 'https';",
    "import https from 'https';\nimport http, { type IncomingMessage } from 'http';",
    "http import",
)

ipc = replace_once(
    ipc,
    "getDb, upsertLearners, upsertStaff, addToOutbox, getPendingOps, markOpStatus,",
    "getDb, upsertLearners, upsertClasses, upsertStaff, addToOutbox, getPendingOps, markOpStatus,",
    "upsertClasses import",
)

if "function fetchImageDataUrl(" not in ipc:
    helper_code = r"""
function resolveImageUrl(rawUrl: string): URL {
  const value = String(rawUrl ?? '').trim();

  if (!value) throw new Error('Logo URL is empty.');
  if (value.startsWith('//')) return new URL(`https:${value}`);

  return new URL(value, 'https://academiaos.cc');
}

function fetchImageDataUrl(
  rawUrl: string,
  accessToken?: string,
  redirectCount = 0,
): Promise<string> {
  if (rawUrl.startsWith('data:image/')) {
    return Promise.resolve(rawUrl);
  }

  if (redirectCount > 5) {
    return Promise.reject(new Error('Too many logo redirects.'));
  }

  const url = resolveImageUrl(rawUrl);
  const isAcademiaHost =
    url.hostname === 'academiaos.cc' ||
    url.hostname.endsWith('.academiaos.cc');

  return new Promise((resolve, reject) => {
    const onResponse = (response: IncomingMessage) => {
      const status = response.statusCode ?? 0;

      if (
        [301, 302, 303, 307, 308].includes(status) &&
        response.headers.location
      ) {
        response.resume();
        const nextUrl = new URL(
          response.headers.location,
          url,
        ).toString();

        fetchImageDataUrl(
          nextUrl,
          accessToken,
          redirectCount + 1,
        ).then(resolve, reject);
        return;
      }

      if (status < 200 || status >= 300) {
        response.resume();
        reject(new Error(`Logo request returned HTTP ${status}.`));
        return;
      }

      const mime = String(
        response.headers['content-type'] ?? 'image/png',
      ).split(';')[0].trim();

      if (!mime.startsWith('image/')) {
        response.resume();
        reject(new Error(`Logo response is ${mime}.`));
        return;
      }

      const chunks: Buffer[] = [];
      let total = 0;

      response.on('data', (chunk: Buffer) => {
        total += chunk.length;

        if (total > 10 * 1024 * 1024) {
          request.destroy(
            new Error('School logo is larger than 10 MB.'),
          );
          return;
        }

        chunks.push(chunk);
      });

      response.on('end', () => {
        const image = Buffer.concat(chunks);
        resolve(
          `data:${mime};base64,${image.toString('base64')}`,
        );
      });
    };

    const options = {
      headers: {
        'User-Agent': `AcademiaOS-Desktop/${APP_VERSION}`,
        Accept: 'image/*',
        ...(accessToken && isAcademiaHost
          ? { Authorization: `Bearer ${accessToken}` }
          : {}),
      },
      timeout: 30_000,
    };

    const request =
      url.protocol === 'http:'
        ? http.request(url, options, onResponse)
        : https.request(url, options, onResponse);

    request.on('timeout', () => {
      request.destroy(new Error('Logo request timed out.'));
    });

    request.on('error', reject);
    request.end();
  });
}

"""
    marker = "// ── Device identifier"
    if marker not in ipc:
        raise RuntimeError("Could not locate Device identifier marker")
    ipc = ipc.replace(marker, helper_code + marker, 1)

ipc = replace_once(
    ipc,
    """      if (Array.isArray(d.learners) && (d.learners as unknown[]).length > 0) {
        upsertLearners(db, d.learners as Record<string, unknown>[]);
      }

      if (Array.isArray(d.staff) && (d.staff as unknown[]).length > 0) {
""",
    """      if (Array.isArray(d.learners) && (d.learners as unknown[]).length > 0) {
        upsertLearners(db, d.learners as Record<string, unknown>[]);
      }

      if (Array.isArray(d.classes)) {
        upsertClasses(db, d.classes as Record<string, unknown>[]);
      }

      if (Array.isArray(d.staff) && (d.staff as unknown[]).length > 0) {
""",
    "initial classes",
)

ipc = replace_once(
    ipc,
    """      db.prepare(`
        INSERT OR REPLACE INTO sync_cursor (entity_type, last_synced, record_count)
        VALUES (?, ?, ?)
      `).run('staff', d.syncCursor, (d.staff as unknown[])?.length ?? 0);

      return { ok: true, data: d };
""",
    """      db.prepare(`
        INSERT OR REPLACE INTO sync_cursor (entity_type, last_synced, record_count)
        VALUES (?, ?, ?)
      `).run('staff', d.syncCursor, (d.staff as unknown[])?.length ?? 0);

      db.prepare(`
        INSERT OR REPLACE INTO sync_cursor (entity_type, last_synced, record_count)
        VALUES (?, ?, ?)
      `).run('classes', d.syncCursor, (d.classes as unknown[])?.length ?? 0);

      return { ok: true, data: d };
""",
    "class cursor",
)

ipc = replace_once(
    ipc,
    """      if (chg?.learners?.length) upsertLearners(db, chg.learners as Record<string, unknown>[]);
      if (chg?.staff?.length) upsertStaff(db, chg.staff as Record<string, unknown>[]);
""",
    """      if (chg?.learners?.length) upsertLearners(db, chg.learners as Record<string, unknown>[]);
      if (chg?.classes?.length) upsertClasses(db, chg.classes as Record<string, unknown>[]);
      if (chg?.staff?.length) upsertStaff(db, chg.staff as Record<string, unknown>[]);
""",
    "incremental classes",
)

handler_pattern = re.compile(
    r"  // ── db:getLearners.*?\n"
    r"  ipcMain\.handle\('db:getLearners'.*?\n"
    r"  \}\);\n\n"
    r"  // ── db:getStaff",
    re.S,
)

handler_replacement = r"""  // ── db:getLearners
  ipcMain.handle('db:getLearners', async (_, opts: {
    classId?: string;
    search?: string;
  } = {}) => {
    const db = getDb();

    let sql = `
      SELECT
        l.*,
        c.name AS class_name,
        c.stream AS class_stream
      FROM cached_learners l
      LEFT JOIN cached_classes c ON c.id = l.class_id
      WHERE l.status = 'ACTIVE'
    `;

    const args: (string | number)[] = [];

    if (opts.classId) {
      sql += ` AND l.class_id = ?`;
      args.push(opts.classId);
    }

    if (opts.search) {
      const q = `%${opts.search}%`;
      sql += `
        AND (
          l.first_name LIKE ?
          OR l.last_name LIKE ?
          OR l.admission_no LIKE ?
        )
      `;
      args.push(q, q, q);
    }

    sql += ` ORDER BY l.last_name, l.first_name LIMIT 500`;

    return {
      ok: true,
      learners: db.prepare(sql).all(...args),
    };
  });

  // ── db:getStaff"""

updated, count = handler_pattern.subn(handler_replacement, ipc, count=1)
if count == 0 and "c.name AS class_name" not in ipc:
    raise RuntimeError("Could not replace db:getLearners handler")
ipc = updated

if "ipcMain.handle('media:loadImage'" not in ipc:
    media_handler = r"""
  // ── media:loadImage
  ipcMain.handle('media:loadImage', async (_, payload: {
    url: string;
  }) => {
    try {
      const accessToken = await getCredential(
        ACCOUNT_ACCESS_TOKEN,
      );

      const dataUrl = await fetchImageDataUrl(
        payload.url,
        accessToken ?? undefined,
      );

      return { ok: true, dataUrl };
    } catch (error) {
      return {
        ok: false,
        error: {
          code: 'LOGO_LOAD_FAILED',
          message: String(error),
        },
      };
    }
  });

"""
    marker = "  // ── app:getVersion"
    if marker not in ipc:
        raise RuntimeError("Could not locate app:getVersion marker")
    ipc = ipc.replace(marker, media_handler + marker, 1)

write(ipc_path, ipc)

print("Source repair applied successfully.")
print("Version: 1.0.9")
