/**
 * POST /api/desktop/v1/sync/outbox
 *
 * Accepts an array of offline operations captured by the desktop client and
 * applies them server-side with DB-persisted idempotency enforcement.
 *
 * Idempotency keys are stored in `desktop_outbox_idempotency_keys` so that
 * duplicate transmissions produce exactly one logical server mutation even
 * across server restarts and multi-instance deployments.
 *
 * HIGH-RISK operations (final financial postings, approvals, user creation,
 * etc.) are explicitly rejected here.  They must be performed online via the
 * main web UI where proper authorisation and audit trails exist.
 *
 * Financial conflicts NEVER use silent last-write-wins.
 * CONFLICT status is returned and preserved for manual review.
 */
import { and, eq } from 'drizzle-orm';
import { NextRequest } from 'next/server';
import { z } from 'zod';
import { db } from '@/db';
import { attendanceRecords, desktopOutboxIdempotencyKeys, learners } from '@/db/schema';
import { audit } from '@/lib/auth';
import {
  authenticateDesktopRequest, desktopError, desktopJson, resolveDesktopSchoolId,
} from '@/lib/desktop-api';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

// ── Operation schemas ─────────────────────────────────────────────────────────
const baseOp = z.object({
  operationId:    z.string().uuid(),
  idempotencyKey: z.string().uuid(),
  deviceId:       z.string(),
  schoolId:       z.string(),
  createdAt:      z.string().datetime(),
  recordVersion:  z.number().optional(),
});

const attendanceOp = baseOp.extend({
  type:    z.literal('ATTENDANCE_RECORD'),
  payload: z.object({
    learnerId:    z.string(),
    date:         z.string().date(),
    status:       z.enum(['PRESENT', 'ABSENT', 'LATE', 'EXCUSED', 'HALF_DAY']),
    checkInTime:  z.string().datetime().nullable().optional(),
    checkOutTime: z.string().datetime().nullable().optional(),
    reason:       z.string().max(500).optional(),
  }),
});

// Extend here for future operation types: daily fees, marks, visitor, etc.
// Financial operations must be explicitly listed and guarded below.
const BLOCKED_TYPES = new Set([
  'FEE_FINAL_POST', 'PAYMENT_APPROVAL', 'REFUND', 'WITHDRAWAL',
  'RESULT_PUBLISH', 'USER_CREATE', 'USER_ROLE_CHANGE',
]);

const anyOp = z.discriminatedUnion('type', [attendanceOp]);
const bodySchema = z.object({ operations: z.array(anyOp).min(1).max(100) });

// ── Idempotency helpers ───────────────────────────────────────────────────────
async function findExistingKey(idempotencyKey: string) {
  return (await db
    .select()
    .from(desktopOutboxIdempotencyKeys)
    .where(eq(desktopOutboxIdempotencyKeys.idempotencyKey, idempotencyKey))
    .limit(1))[0] ?? null;
}

async function recordKey(opts: {
  idempotencyKey: string;
  schoolId: string | null;
  userId: string;
  operationType: string;
  result: 'ok' | 'rejected';
  errorMessage?: string;
}) {
  await db.insert(desktopOutboxIdempotencyKeys).values({
    idempotencyKey: opts.idempotencyKey,
    schoolId:       opts.schoolId,
    userId:         opts.userId,
    operationType:  opts.operationType,
    result:         opts.result,
    errorMessage:   opts.errorMessage ?? null,
  }).onConflictDoNothing(); // race-safe: two pods may race; first writer wins
}

// ─────────────────────────────────────────────────────────────────────────────
export async function POST(request: NextRequest) {
  const auth = await authenticateDesktopRequest(request);
  if ('response' in auth) return auth.response;
  const ctx = auth.context;

  let body: unknown;
  try { body = await request.json(); } catch {
    return desktopError(400, 'INVALID_JSON', 'Send a valid JSON body.');
  }

  // Validate structure — discriminatedUnion only accepts known types
  // Unknown operation types that are not in BLOCKED_TYPES just fail validation
  const parsed = bodySchema.safeParse(body);

  // Check for blocked types before full validation error
  const rawOps = Array.isArray((body as Record<string, unknown>)?.operations)
    ? (body as { operations: Array<{ type?: string }> }).operations
    : [];
  const blockedOp = rawOps.find((op) => BLOCKED_TYPES.has(op?.type ?? ''));
  if (blockedOp) {
    return desktopError(400, 'BLOCKED_OPERATION',
      `Operation type '${blockedOp.type}' is not permitted via offline sync. Use the web interface.`);
  }

  if (!parsed.success) {
    return desktopError(400, 'INVALID_OPERATIONS',
      parsed.error.issues[0]?.message ?? 'Invalid operations payload.');
  }

  const schoolId = await resolveDesktopSchoolId(ctx, request);
  if (!schoolId) return desktopError(400, 'NO_SCHOOL', 'Could not resolve school for this session.');

  const results: Array<{
    operationId: string; idempotencyKey: string; status: string; message?: string;
  }> = [];

  for (const op of parsed.data.operations) {
    // Guard: schoolId in payload must match authenticated session
    if (op.schoolId !== schoolId) {
      results.push({
        operationId:    op.operationId,
        idempotencyKey: op.idempotencyKey,
        status: 'REJECTED', message: 'schoolId mismatch',
      });
      continue;
    }

    // ── DB-persisted idempotency check ────────────────────────────────────
    const existing = await findExistingKey(op.idempotencyKey);
    if (existing) {
      results.push({
        operationId:    op.operationId,
        idempotencyKey: op.idempotencyKey,
        status: 'ALREADY_PROCESSED',
      });
      continue;
    }

    // ── Execute the operation ─────────────────────────────────────────────
    try {
      if (op.type === 'ATTENDANCE_RECORD') {
        // Verify learner belongs to this school
        const learner = (await db
          .select({ id: learners.id })
          .from(learners)
          .where(and(eq(learners.id, op.payload.learnerId), eq(learners.schoolId, schoolId)))
          .limit(1))[0];

        if (!learner) throw new Error('Learner not found in this school');

        const attendanceDate = new Date(op.payload.date);
        const existing = await db.select({ id: attendanceRecords.id })
          .from(attendanceRecords)
          .where(and(
            eq(attendanceRecords.learnerId, op.payload.learnerId),
            eq(attendanceRecords.date, attendanceDate),
          )).limit(1);

        if (existing.length > 0) {
          // Attendance already exists for this learner/date — not a conflict,
          // treat as already-synced (the onConflictDoNothing path)
          await recordKey({
            idempotencyKey: op.idempotencyKey, schoolId, userId: ctx.user.id,
            operationType: op.type, result: 'ok',
          });
          results.push({
            operationId: op.operationId, idempotencyKey: op.idempotencyKey,
            status: 'ALREADY_PROCESSED',
          });
          continue;
        }

        await db.insert(attendanceRecords).values({
          schoolId,
          learnerId:    op.payload.learnerId,
          date:         attendanceDate,
          status:       op.payload.status,
          checkInTime:  op.payload.checkInTime  ? new Date(op.payload.checkInTime)  : null,
          checkOutTime: op.payload.checkOutTime ? new Date(op.payload.checkOutTime) : null,
          reason:       op.payload.reason ?? null,
          recordedById: ctx.user.id,
        });

        await audit({
          schoolId, userId: ctx.user.id,
          action: 'DESKTOP_ATTENDANCE_SYNCED',
          entityType: 'AttendanceRecord',
          entityId: op.payload.learnerId,
          newValue: { idempotencyKey: op.idempotencyKey, status: op.payload.status, date: op.payload.date },
        });
      }

      // Record successful idempotency key in DB
      await recordKey({
        idempotencyKey: op.idempotencyKey, schoolId, userId: ctx.user.id,
        operationType: op.type, result: 'ok',
      });
      results.push({
        operationId:    op.operationId,
        idempotencyKey: op.idempotencyKey,
        status: 'SYNCED',
      });

    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      // Record failed idempotency key — prevents the client from retrying
      // indefinitely for a hard error (learner not found, schema mismatch, etc.)
      await recordKey({
        idempotencyKey: op.idempotencyKey, schoolId, userId: ctx.user.id,
        operationType: op.type, result: 'rejected', errorMessage: msg,
      }).catch(() => {}); // best-effort; don't mask the original error

      results.push({
        operationId:    op.operationId,
        idempotencyKey: op.idempotencyKey,
        status: 'REJECTED', message: msg,
      });
    }
  }

  return desktopJson({ data: { results } });
}
