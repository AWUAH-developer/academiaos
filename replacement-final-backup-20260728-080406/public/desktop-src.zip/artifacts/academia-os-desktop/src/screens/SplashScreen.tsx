import React from 'react';
import DevourBrand from '../components/DevourBrand';

export default function SplashScreen() {
  return (
    <div className="desktop-splash" aria-label="Opening AcademiaOS">
      <DevourBrand holdMs={350} />
      <div className="desktop-splash-tag">School Command Centre</div>
    </div>
  );
}
