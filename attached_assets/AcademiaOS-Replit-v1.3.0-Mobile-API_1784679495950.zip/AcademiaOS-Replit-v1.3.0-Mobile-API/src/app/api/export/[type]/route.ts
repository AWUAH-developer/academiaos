import { and, desc, eq, inArray } from 'drizzle-orm';
import { NextResponse } from 'next/server';
import { db } from '@/db';
import {
  academicSubmissions,
  academicYears,
  attendanceRecords,
  auditLogs,
  classes,
  learners,
  payments,
  staffAttendanceRecords,
  subjects,
  terms,
  transportRoutes,
  transportScans,
  users,
  vehicles
} from '@/db/schema';
import { visibleLearnerIds } from '@/lib/access';
import { currentUser } from '@/lib/auth';
import { canAccess } from '@/lib/permissions';
import { getActiveSchoolId } from '@/lib/tenant';

function csvCell(value: unknown) {
  if (value === null || value === undefined) return '';
  const text = value instanceof Date ? value.toISOString() : String(value);
  // Prevent spreadsheet formula injection when exported data is opened in Excel or similar tools.
  const safeText = /^[=+\-@]/.test(text.trimStart()) ? `'${text}` : text;
  return /[",\r\n]/.test(safeText) ? `"${safeText.replaceAll('"', '""')}"` : safeText;
}

function makeCsv(headers: string[], rows: unknown[][]) {
  const body = [headers, ...rows].map((row) => row.map(csvCell).join(',')).join('\r\n');
  return `\uFEFF${body}`;
}

function csvResponse(type: string, headers: string[], rows: unknown[][]) {
  const stamp = new Date().toISOString().slice(0, 10);
  return new NextResponse(makeCsv(headers, rows), {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="academiaos-${type}-${stamp}.csv"`,
      'Cache-Control': 'private, no-store'
    }
  });
}

export async function GET(_request: Request, context: { params: Promise<{ type: string }> }) {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: 'Authentication required.' }, { status: 401 });

  const { type } = await context.params;
  const schoolId = await getActiveSchoolId(user);
  const learnerScope = await visibleLearnerIds(user);
  const learnerFilter = learnerScope === null
    ? undefined
    : learnerScope.length
      ? inArray(learners.id, learnerScope)
      : eq(learners.id, '__none__');

  if (type === 'learners') {
    if (!canAccess(user.role, 'learners')) return NextResponse.json({ error: 'Permission denied.' }, { status: 403 });
    const rows = await db.select({ learner: learners, className: classes.name, stream: classes.stream })
      .from(learners).leftJoin(classes, eq(learners.classId, classes.id))
      .where(and(eq(learners.schoolId, schoolId), learnerFilter)).orderBy(learners.admissionNo);
    return csvResponse(type,
      ['Admission number','First name','Last name','Class','Stream','Gender','Payment plan','Badge code','Status','Admission date'],
      rows.map(({ learner, className, stream }) => [learner.admissionNo, learner.firstName, learner.lastName, className, stream, learner.gender, learner.paymentPlan, learner.badgeCode, learner.status, learner.admissionDate])
    );
  }

  if (type === 'attendance') {
    if (!canAccess(user.role, 'attendance')) return NextResponse.json({ error: 'Permission denied.' }, { status: 403 });
    const rows = await db.select({ attendance: attendanceRecords, learner: learners, className: classes.name, stream: classes.stream, recorder: users.name })
      .from(attendanceRecords)
      .innerJoin(learners, eq(attendanceRecords.learnerId, learners.id))
      .leftJoin(classes, eq(learners.classId, classes.id))
      .leftJoin(users, eq(attendanceRecords.recordedById, users.id))
      .where(and(eq(attendanceRecords.schoolId, schoolId), learnerFilter))
      .orderBy(desc(attendanceRecords.date)).limit(10000);
    return csvResponse(type,
      ['Date','Admission number','Learner','Class','Stream','Status','Check-in','Check-out','Reason','Recorded by'],
      rows.map(({ attendance, learner, className, stream, recorder }) => [attendance.date, learner.admissionNo, `${learner.firstName} ${learner.lastName}`, className, stream, attendance.status, attendance.checkInTime, attendance.checkOutTime, attendance.reason, recorder])
    );
  }

  if (type === 'fees') {
    if (!canAccess(user.role, 'fees')) return NextResponse.json({ error: 'Permission denied.' }, { status: 403 });
    const rows = await db.select({ payment: payments, learner: learners, recorder: users.name })
      .from(payments).innerJoin(learners, eq(payments.learnerId, learners.id)).leftJoin(users, eq(payments.recordedById, users.id))
      .where(and(eq(payments.schoolId, schoolId), learnerFilter)).orderBy(desc(payments.createdAt)).limit(10000);
    return csvResponse(type,
      ['Receipt number','Date','Admission number','Learner','Amount','Method','Reference','Notes','Recorded by'],
      rows.map(({ payment, learner, recorder }) => [payment.receiptNo, payment.createdAt, learner.admissionNo, `${learner.firstName} ${learner.lastName}`, payment.amount, payment.method, payment.reference, payment.notes, recorder])
    );
  }

  if (type === 'academics') {
    if (!canAccess(user.role, 'academics') && !canAccess(user.role, 'reports')) return NextResponse.json({ error: 'Permission denied.' }, { status: 403 });
    const visibility = learnerScope === null ? undefined : inArray(academicSubmissions.status, ['LOCKED']);
    const rows = await db.select({ result: academicSubmissions, learner: learners, className: classes.name, stream: classes.stream, subjectName: subjects.name, yearName: academicYears.name, termName: terms.name, teacherName: users.name })
      .from(academicSubmissions)
      .innerJoin(learners, eq(academicSubmissions.learnerId, learners.id))
      .innerJoin(classes, eq(academicSubmissions.classId, classes.id))
      .innerJoin(subjects, eq(academicSubmissions.subjectId, subjects.id))
      .innerJoin(academicYears, eq(academicSubmissions.academicYearId, academicYears.id))
      .innerJoin(terms, eq(academicSubmissions.termId, terms.id))
      .leftJoin(users, eq(academicSubmissions.teacherId, users.id))
      .where(and(eq(academicSubmissions.schoolId, schoolId), learnerFilter, visibility))
      .orderBy(desc(academicSubmissions.updatedAt)).limit(10000);
    return csvResponse(type,
      ['Academic year','Term','Admission number','Learner','Class','Stream','Subject','Classwork','Homework','Test','Examination','Total','Grade','Position','Teacher remark','Conduct remark','Status','Teacher'],
      rows.map(({ result, learner, className, stream, subjectName, yearName, termName, teacherName }) => [yearName, termName, learner.admissionNo, `${learner.firstName} ${learner.lastName}`, className, stream, subjectName, result.classworkScore, result.homeworkScore, result.testScore, result.examScore, result.totalScore, result.grade, result.position, result.teacherRemark, result.conductRemark, result.status, teacherName])
    );
  }

  if (type === 'staff-attendance') {
    if (!canAccess(user.role, 'staff-attendance')) return NextResponse.json({ error: 'Permission denied.' }, { status: 403 });
    const supervisor = ['SUPER_ADMIN','SCHOOL_ADMIN','PROPRIETOR','HEADTEACHER'].includes(user.role);
    const rows = await db.select({ attendance: staffAttendanceRecords, staffName: users.name, staffRole: users.role })
      .from(staffAttendanceRecords).innerJoin(users, eq(staffAttendanceRecords.staffId, users.id))
      .where(and(eq(staffAttendanceRecords.schoolId, schoolId), supervisor ? undefined : eq(staffAttendanceRecords.staffId, user.id)))
      .orderBy(desc(staffAttendanceRecords.date)).limit(10000);
    return csvResponse(type,
      ['Date','Staff member','Role','Status','Arrival','Departure','Late arrival','Early departure','Reason'],
      rows.map(({ attendance, staffName, staffRole }) => [attendance.date, staffName, staffRole, attendance.status, attendance.arrivalTime, attendance.departureTime, attendance.lateArrival, attendance.earlyDeparture, attendance.reason])
    );
  }

  if (type === 'transport') {
    if (!canAccess(user.role, 'transport')) return NextResponse.json({ error: 'Permission denied.' }, { status: 403 });
    const rows = await db.select({ scan: transportScans, learner: learners, routeName: transportRoutes.name, vehicleName: vehicles.name, recorder: users.name })
      .from(transportScans)
      .innerJoin(learners, eq(transportScans.learnerId, learners.id))
      .leftJoin(transportRoutes, eq(transportScans.routeId, transportRoutes.id))
      .leftJoin(vehicles, eq(transportScans.vehicleId, vehicles.id))
      .leftJoin(users, eq(transportScans.recordedById, users.id))
      .where(eq(transportScans.schoolId, schoolId)).orderBy(desc(transportScans.scannedAt)).limit(10000);
    return csvResponse(type,
      ['Date and time','Admission number','Learner','Event','Route','Vehicle','Notification status','Recorded by'],
      rows.map(({ scan, learner, routeName, vehicleName, recorder }) => [scan.scannedAt, learner.admissionNo, `${learner.firstName} ${learner.lastName}`, scan.type, routeName, vehicleName, scan.notificationStatus, recorder])
    );
  }

  if (type === 'audit') {
    if (!canAccess(user.role, 'audit')) return NextResponse.json({ error: 'Permission denied.' }, { status: 403 });
    const rows = await db.select({ log: auditLogs, actor: users.name })
      .from(auditLogs).leftJoin(users, eq(auditLogs.userId, users.id))
      .where(eq(auditLogs.schoolId, schoolId)).orderBy(desc(auditLogs.createdAt)).limit(10000);
    return csvResponse(type,
      ['Date and time','Actor','Action','Entity type','Entity ID','IP address','User agent','Previous value','New value'],
      rows.map(({ log, actor }) => [log.createdAt, actor, log.action, log.entityType, log.entityId, log.ipAddress, log.userAgent, JSON.stringify(log.oldValue ?? ''), JSON.stringify(log.newValue ?? '')])
    );
  }

  return NextResponse.json({ error: 'Unknown export type.' }, { status: 404 });
}
