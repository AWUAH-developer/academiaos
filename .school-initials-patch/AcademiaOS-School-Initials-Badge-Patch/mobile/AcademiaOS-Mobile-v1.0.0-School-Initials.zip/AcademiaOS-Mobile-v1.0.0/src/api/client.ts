import type {
  AcademiaUser, Announcement, ApiEnvelope, AppNotification, AttendanceRecord, AttendanceStatus,
  FeeCharge, FeeSummary, Learner, MobileDevice, Payment, ResultRecord, SessionTokens, TerminalReport
} from './types';
import { clearTokens, getAccessToken, getRefreshToken, saveTokens } from '@/lib/storage';
import { deviceIdentity } from '@/lib/device';

const rawApiUrl = process.env.EXPO_PUBLIC_ACADEMIAOS_API_URL?.trim().replace(/\/$/, '');
let refreshPromise: Promise<string> | null = null;
const expiredListeners = new Set<() => void>();

export class AcademiaApiError extends Error {
  constructor(public status: number, public code: string, message: string) { super(message); }
}

function apiUrl() {
  if (!rawApiUrl) throw new Error('EXPO_PUBLIC_ACADEMIAOS_API_URL is missing. Copy .env.example to .env and add the Replit API URL.');
  const local = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?\//.test(`${rawApiUrl}/`);
  if (!rawApiUrl.startsWith('https://') && !local) throw new Error('The AcademiaOS API URL must use HTTPS.');
  return rawApiUrl;
}

async function parse<T>(response: Response): Promise<T> {
  const body = await response.json().catch(() => ({})) as { error?: { code?: string; message?: string } } & T;
  if (!response.ok) throw new AcademiaApiError(response.status, body.error?.code || 'REQUEST_FAILED', body.error?.message || 'The request failed.');
  return body;
}

export function onSessionExpired(listener: () => void) {
  expiredListeners.add(listener);
  return () => expiredListeners.delete(listener);
}
function emitExpired() { expiredListeners.forEach((listener) => listener()); }

export async function clearMobileSession() { await clearTokens(); }
export async function hasMobileSession() { return Boolean(await getRefreshToken()); }

async function rotateTokens() {
  const refreshToken = await getRefreshToken();
  if (!refreshToken) throw new AcademiaApiError(401, 'AUTH_REQUIRED', 'Sign in again.');
  const response = await fetch(`${apiUrl()}/auth/refresh`, {
    method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
    body: JSON.stringify({ refreshToken })
  });
  const body = await parse<ApiEnvelope<{ tokens: SessionTokens }>>(response);
  await saveTokens(body.data.tokens.accessToken, body.data.tokens.refreshToken);
  return body.data.tokens.accessToken;
}
async function refreshedAccessToken() {
  if (!refreshPromise) refreshPromise = rotateTokens().finally(() => { refreshPromise = null; });
  return refreshPromise;
}

export async function apiRequest<T>(path: string, init: RequestInit = {}, retry = true): Promise<T> {
  const accessToken = await getAccessToken();
  if (!accessToken) throw new AcademiaApiError(401, 'AUTH_REQUIRED', 'Sign in again.');
  const headers: Record<string, string> = { Accept: 'application/json', Authorization: `Bearer ${accessToken}` };
  if (init.body) headers['Content-Type'] = 'application/json';
  Object.assign(headers, init.headers || {});
  const response = await fetch(`${apiUrl()}${path.startsWith('/') ? path : `/${path}`}`, { ...init, headers });
  if (response.status === 401 && retry) {
    try { await refreshedAccessToken(); return apiRequest<T>(path, init, false); }
    catch (error) { await clearTokens(); emitExpired(); throw error; }
  }
  return parse<T>(response);
}

export async function login(username: string, password: string) {
  const identity = await deviceIdentity();
  const response = await fetch(`${apiUrl()}/auth/login`, {
    method: 'POST', headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password, ...identity })
  });
  const body = await parse<ApiEnvelope<{ user: AcademiaUser; tokens: SessionTokens }>>(response);
  await saveTokens(body.data.tokens.accessToken, body.data.tokens.refreshToken);
  return body.data;
}
export async function logout() {
  try { await apiRequest('/auth/logout', { method: 'POST' }, false); }
  finally { await clearTokens(); }
}
export async function changePassword(currentPassword: string, newPassword: string, confirmPassword: string) {
  const body = await apiRequest<ApiEnvelope<{ user: AcademiaUser; tokens: SessionTokens }>>('/auth/change-password', {
    method: 'POST', body: JSON.stringify({ currentPassword, newPassword, confirmPassword })
  });
  await saveTokens(body.data.tokens.accessToken, body.data.tokens.refreshToken);
  return body.data.user;
}
export async function getProfile() { return (await apiRequest<ApiEnvelope<{ user: AcademiaUser }>>('/profile')).data.user; }
export async function getLearners(learnerId?: string) {
  const query = learnerId ? `?learnerId=${encodeURIComponent(learnerId)}` : '?limit=100';
  return (await apiRequest<ApiEnvelope<{ learners: Learner[] }>>(`/learners${query}`)).data.learners;
}
export async function getAttendance(learnerId?: string, days = 90) {
  const to = new Date(); const from = new Date(Date.now() - days * 86_400_000);
  const query = new URLSearchParams({ limit: '200', from: from.toISOString().slice(0, 10), to: to.toISOString().slice(0, 10) });
  if (learnerId) query.set('learnerId', learnerId);
  return (await apiRequest<ApiEnvelope<{ attendance: AttendanceRecord[] }>>(`/attendance?${query}`)).data.attendance;
}
export async function recordAttendance(input: { learnerId: string; date: string; status: AttendanceStatus; reason?: string }) {
  return (await apiRequest<ApiEnvelope<{ attendance: AttendanceRecord }>>('/attendance', { method: 'POST', body: JSON.stringify(input) })).data.attendance;
}
export async function getFees(learnerId?: string) {
  const query = learnerId ? `?learnerId=${encodeURIComponent(learnerId)}&limit=200` : '?limit=200';
  return (await apiRequest<ApiEnvelope<{ summary: FeeSummary[]; charges: FeeCharge[] }>>(`/fees${query}`)).data;
}
export async function getPayments(learnerId?: string) {
  const query = learnerId ? `?learnerId=${encodeURIComponent(learnerId)}&limit=200` : '?limit=200';
  return (await apiRequest<ApiEnvelope<{ payments: Payment[] }>>(`/payments${query}`)).data.payments;
}
export async function getResults(learnerId?: string) {
  const query = learnerId ? `?learnerId=${encodeURIComponent(learnerId)}&limit=200` : '?limit=200';
  return (await apiRequest<ApiEnvelope<{ results: ResultRecord[] }>>(`/results${query}`)).data.results;
}
export async function getReports(learnerId?: string) {
  const query = learnerId ? `?learnerId=${encodeURIComponent(learnerId)}&limit=100` : '?limit=100';
  return (await apiRequest<ApiEnvelope<{ reports: TerminalReport[] }>>(`/reports${query}`)).data.reports;
}
export async function getAnnouncements() { return (await apiRequest<ApiEnvelope<{ announcements: Announcement[] }>>('/announcements?limit=100')).data.announcements; }
export async function getNotifications(unreadOnly = false) { return (await apiRequest<ApiEnvelope<{ notifications: AppNotification[] }>>(`/notifications?limit=100&unreadOnly=${unreadOnly}`)).data.notifications; }
export async function markNotifications(input: { notificationIds?: string[]; markAll?: boolean }) {
  return (await apiRequest<ApiEnvelope<{ updated: string[] }>>('/notifications', { method: 'PATCH', body: JSON.stringify(input) })).data.updated;
}
export async function getDevices() { return (await apiRequest<ApiEnvelope<{ devices: MobileDevice[]; currentDeviceId: string }>>('/devices')).data; }
export async function updateDevice(input: { deviceName?: string; appVersion?: string; pushToken?: string | null; notificationsEnabled?: boolean }) {
  return (await apiRequest<ApiEnvelope<{ device: MobileDevice }>>('/devices', { method: 'POST', body: JSON.stringify(input) })).data.device;
}
export async function revokeDevice(deviceId: string) { return apiRequest<ApiEnvelope<{ revoked: boolean }>>(`/devices?deviceId=${encodeURIComponent(deviceId)}`, { method: 'DELETE' }); }
export async function getApiStatus() {
  const response = await fetch(`${apiUrl()}/status`, { headers: { Accept: 'application/json' } });
  return parse<ApiEnvelope<{ service: string; version: string; database: string }>>(response);
}
