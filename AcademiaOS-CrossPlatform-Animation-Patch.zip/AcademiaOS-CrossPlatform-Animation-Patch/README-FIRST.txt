ACADEMIAOS CROSS-PLATFORM ANIMATION PATCH

Scope:
1. Website + authenticated web app: web-app/src and web-app/public
2. Mobile app: mobile-app/AcademiaOS-Mobile-v1.0.0-Animated.zip
3. Desktop app: desktop-app/academia-os-desktop-updated.zip

The animation is the AcademiaOS yellow-circle sequential letter devour effect.

IMPORTANT:
- Do not publish the web deployment until the web-app patch is applied and typecheck/build pass.
- The mobile app is a separate Expo project. Its animated source is provided as the complete updated mobile ZIP.
- The desktop app source is provided as the complete updated desktop ZIP and the web patch also replaces the desktop download artifacts in public/.
- No database, migration, authentication, homework, attendance, fees, reporting, or API business logic is intentionally changed by this patch.
